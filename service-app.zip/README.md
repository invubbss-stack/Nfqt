# 🔧 خدماتي — منصة طلب الخدمات

تطبيق ويب متكامل لاستقبال وإدارة طلبات الخدمات مع لوحة تحكم احترافية وإشعارات فورية.

---

## 📁 هيكل المشروع

```
service-app/
├── backend/                        # الخادم - Node.js + Express
│   ├── src/
│   │   ├── config/
│   │   │   ├── database.js         # اتصال قاعدة البيانات
│   │   │   └── migrate.js          # إنشاء الجداول والبيانات الأولية
│   │   ├── controllers/
│   │   │   ├── authController.js   # تسجيل الدخول وإدارة المشرف
│   │   │   └── requestController.js# CRUD كامل للطلبات
│   │   ├── middleware/
│   │   │   ├── auth.js             # JWT authentication middleware
│   │   │   └── upload.js           # Multer file upload middleware
│   │   ├── routes/
│   │   │   ├── auth.js             # مسارات المصادقة
│   │   │   └── requests.js         # مسارات الطلبات
│   │   ├── utils/
│   │   │   ├── email.js            # إرسال إشعارات البريد الإلكتروني
│   │   │   └── helpers.js          # توليد رقم الطلب
│   │   └── server.js               # نقطة الدخول الرئيسية + Socket.io
│   ├── uploads/                    # ملفات المرفقات
│   ├── Dockerfile
│   ├── package.json
│   └── .env.example
│
├── frontend/                       # الواجهة - React + Tailwind CSS
│   ├── src/
│   │   ├── assets/
│   │   │   └── globals.css         # نظام التصميم والألوان
│   │   ├── components/
│   │   │   └── shared/
│   │   │       └── ProtectedRoute.js
│   │   ├── context/
│   │   │   └── AuthContext.js      # إدارة حالة المصادقة
│   │   ├── hooks/
│   │   │   └── useSocket.js        # Socket.io real-time hook
│   │   ├── pages/
│   │   │   ├── ClientPage.js       # الصفحة الرئيسية + نموذج الطلب
│   │   │   ├── LoginPage.js        # صفحة تسجيل الدخول
│   │   │   └── AdminPage.js        # لوحة التحكم الكاملة
│   │   ├── utils/
│   │   │   └── api.js              # Axios instance مع interceptors
│   │   ├── App.js                  # Routing الرئيسي
│   │   └── index.js
│   ├── public/
│   │   └── index.html
│   ├── Dockerfile
│   └── package.json
│
├── docker-compose.yml
└── README.md
```

---

## 🗄️ مخطط قاعدة البيانات

### جدول `admins`
| العمود     | النوع         | الوصف                        |
|-----------|--------------|------------------------------|
| id        | INT PK AI    | المعرف الفريد                 |
| name      | VARCHAR(100) | اسم المشرف                   |
| email     | VARCHAR(150) | البريد الإلكتروني (UNIQUE)   |
| password  | VARCHAR(255) | كلمة المرور (bcrypt hashed)  |
| created_at| TIMESTAMP    | تاريخ الإنشاء                |
| updated_at| TIMESTAMP    | آخر تحديث                    |

### جدول `requests`
| العمود         | النوع                                          | الوصف              |
|---------------|-----------------------------------------------|--------------------|
| id            | INT PK AI                                     | المعرف الفريد       |
| request_number| VARCHAR(20) UNIQUE                            | رقم الطلب المرجعي  |
| full_name     | VARCHAR(100)                                  | الاسم الكامل       |
| phone         | VARCHAR(20)                                   | رقم الهاتف         |
| email         | VARCHAR(150) NULL                             | البريد (اختياري)   |
| service_type  | VARCHAR(100)                                  | نوع الخدمة         |
| description   | TEXT                                          | وصف الطلب          |
| attachment    | VARCHAR(255) NULL                             | اسم ملف المرفق     |
| status        | ENUM(new,processing,completed,cancelled)      | حالة الطلب         |
| notes         | TEXT NULL                                     | ملاحظات المشرف     |
| created_at    | TIMESTAMP                                     | تاريخ الإنشاء      |
| updated_at    | TIMESTAMP                                     | آخر تحديث          |

---

## 🌐 API Endpoints

### المصادقة (Auth)
| Method | Endpoint                    | الوصف                | الحماية |
|--------|-----------------------------|---------------------|---------|
| POST   | `/api/auth/login`           | تسجيل الدخول        | ❌      |
| GET    | `/api/auth/profile`         | بيانات المشرف       | ✅ JWT  |
| PUT    | `/api/auth/change-password` | تغيير كلمة المرور   | ✅ JWT  |

### الطلبات (Requests)
| Method | Endpoint                       | الوصف                        | الحماية |
|--------|--------------------------------|------------------------------|---------|
| POST   | `/api/requests`                | إرسال طلب جديد (عام)         | ❌      |
| GET    | `/api/requests`                | جلب جميع الطلبات مع فلتر     | ✅ JWT  |
| GET    | `/api/requests/stats`          | إحصائيات الطلبات             | ✅ JWT  |
| GET    | `/api/requests/:id`            | تفاصيل طلب واحد              | ✅ JWT  |
| PATCH  | `/api/requests/:id/status`     | تحديث حالة الطلب             | ✅ JWT  |
| DELETE | `/api/requests/:id`            | حذف طلب                      | ✅ JWT  |

### معلمات الفلترة (GET /api/requests)
```
?status=new|processing|completed|cancelled
?search=نص البحث
?page=1
?limit=20
?sort=created_at|updated_at|full_name|status
?order=ASC|DESC
```

### Socket.io Events
| Event           | الاتجاه        | الوصف                           |
|-----------------|---------------|---------------------------------|
| `join-admin`    | client → server | المشرف يتصل بالغرفة المحمية    |
| `new-request`   | server → admin | طلب جديد وصل                   |
| `request-updated` | server → admin | تحديث حالة طلب               |

---

## ⚙️ التشغيل المحلي

### المتطلبات
- Node.js 18+
- MySQL 8.0+ (أو MariaDB 10.6+)
- npm أو yarn

### 1. إعداد قاعدة البيانات
```sql
CREATE DATABASE service_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. إعداد Backend
```bash
cd backend
cp .env.example .env
# عدّل .env بمعلومات قاعدة البيانات
npm install
npm run migrate   # ينشئ الجداول ويضيف المشرف الافتراضي
npm run dev       # يبدأ الخادم على المنفذ 5000
```

### 3. إعداد Frontend
```bash
cd frontend
# أنشئ ملف .env.local:
echo "REACT_APP_API_URL=http://localhost:5000/api" > .env.local
echo "REACT_APP_SOCKET_URL=http://localhost:5000" >> .env.local
npm install
npm start         # يبدأ الواجهة على المنفذ 3000
```

### 4. بيانات الدخول الافتراضية
```
البريد: admin@example.com
كلمة المرور: Admin@1234
```

---

## 🐳 النشر باستخدام Docker

### الإعداد السريع
```bash
# 1. انسخ ملف البيئة
cp .env.example .env.prod

# 2. عدّل المتغيرات المهمة:
#    - DB_ROOT_PASSWORD, DB_PASSWORD
#    - JWT_SECRET (مفتاح قوي عشوائي)
#    - ADMIN_EMAIL, ADMIN_PASSWORD
#    - EMAIL_* (إعدادات البريد)
#    - FRONTEND_URL (رابط موقعك)
#    - REACT_APP_API_URL, REACT_APP_SOCKET_URL

# 3. بناء وتشغيل
docker-compose up -d --build

# 4. عرض السجلات
docker-compose logs -f backend
```

---

## 🚀 النشر على VPS

### متطلبات الخادم
- Ubuntu 22.04 LTS
- RAM: 2GB+
- Storage: 20GB+

### الخطوات
```bash
# تثبيت Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# تثبيت Nginx
sudo apt install nginx certbot python3-certbot-nginx -y

# نسخ المشروع
git clone https://github.com/yourusername/service-app.git
cd service-app

# إعداد ومتغيرات البيئة
cp .env.example .env
nano .env  # عدّل جميع القيم

# تشغيل التطبيق
docker-compose up -d --build

# إعداد Nginx كـ Reverse Proxy
sudo nano /etc/nginx/sites-available/service-app
```

```nginx
# /etc/nginx/sites-available/service-app
server {
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /socket.io {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    location /uploads {
        proxy_pass http://localhost:5000;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/service-app /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# SSL مجاني مع Let's Encrypt
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

---

## 🔒 الأمان

- **bcryptjs** — تشفير كلمات المرور (12 rounds)
- **JWT** — مصادقة آمنة مع انتهاء صلاحية
- **Helmet.js** — HTTP security headers
- **Rate Limiting** — 100 طلب/15 دقيقة، 10 إرسال نماذج/ساعة
- **File validation** — التحقق من نوع وحجم الملفات
- **Input validation** — التحقق من جميع المدخلات server-side

---

## 💡 اقتراحات التطوير المستقبلية

### الأولوية العالية (قيمة تجارية مباشرة)
1. **إشعارات واتساب/تيليغرام** — تكامل مع Twilio أو Telegram Bot API لإشعارات فورية
2. **تطبيق موبايل** — React Native يشارك نفس الـ API
3. **نظام تقييم** — يطلب من العميل تقييم الخدمة بعد الإنجاز
4. **تقارير PDF** — تصدير الطلبات كتقرير شهري مع إحصائيات

### توسعة المنصة
5. **تعدد المشرفين والأدوار** — Admin / Supervisor / Technician
6. **نظام الفواتير** — إرسال فاتورة للعميل بعد إنجاز الطلب
7. **تتبع الطلب للعميل** — رابط فريد يتيح للعميل متابعة حالة طلبه
8. **جدولة الزيارات** — تكامل مع تقويم لتحديد موعد الخدمة
9. **متعدد الفروع** — دعم شركات متعددة تحت نفس المنصة (SaaS model)

### تحسينات تقنية
10. **PostgreSQL** — للتطبيقات الكبيرة مع بيانات أكثر
11. **Redis** — caching للإحصائيات + queue للبريد الإلكتروني
12. **MinIO/S3** — تخزين الملفات في السحابة بدلاً من الخادم
13. **Analytics Dashboard** — رسوم بيانية تفاعلية (Chart.js/Recharts)
14. **نسخ احتياطي تلقائي** — cron job يحفظ قاعدة البيانات يومياً

---

## 📞 الدعم

للاستفسارات والتطوير، راجع الـ Issues في مستودع GitHub.
