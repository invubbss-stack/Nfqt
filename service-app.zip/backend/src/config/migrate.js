const { pool } = require('./database');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const migrate = async () => {
  const conn = await pool.getConnection();
  try {
    console.log('🔄 Running database migrations...');

    // Create admins table
    await conn.query(`
      CREATE TABLE IF NOT EXISTS admins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    // Create requests table
    await conn.query(`
      CREATE TABLE IF NOT EXISTS requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        request_number VARCHAR(20) UNIQUE NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        email VARCHAR(150),
        service_type VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        attachment VARCHAR(255),
        status ENUM('new','processing','completed','cancelled') DEFAULT 'new',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_status (status),
        INDEX idx_created_at (created_at),
        INDEX idx_request_number (request_number)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    // Insert default admin if not exists
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@example.com';
    const adminPassword = process.env.ADMIN_PASSWORD || 'Admin@1234';
    const adminName = process.env.ADMIN_NAME || 'Administrator';

    const [existing] = await conn.query('SELECT id FROM admins WHERE email = ?', [adminEmail]);
    if (existing.length === 0) {
      const hashedPassword = await bcrypt.hash(adminPassword, 12);
      await conn.query(
        'INSERT INTO admins (name, email, password) VALUES (?, ?, ?)',
        [adminName, adminEmail, hashedPassword]
      );
      console.log(`✅ Admin created: ${adminEmail}`);
    } else {
      console.log('ℹ️  Admin already exists, skipping...');
    }

    console.log('✅ Migration completed successfully!');
    console.log('\n📋 Default Admin Credentials:');
    console.log(`   Email: ${adminEmail}`);
    console.log(`   Password: ${adminPassword}`);
    console.log('\n⚠️  IMPORTANT: Change the admin password after first login!\n');

  } catch (error) {
    console.error('❌ Migration failed:', error);
    throw error;
  } finally {
    conn.release();
    process.exit(0);
  }
};

migrate();
