const { pool } = require('../config/database');
const { generateRequestNumber } = require('../utils/helpers');
const { sendNewRequestNotification, sendStatusUpdateEmail } = require('../utils/email');

// PUBLIC: Create new request
const createRequest = async (req, res) => {
  const { full_name, phone, email, service_type, description } = req.body;

  if (!full_name || !phone || !service_type || !description) {
    return res.status(400).json({ success: false, message: 'جميع الحقول المطلوبة يجب ملؤها' });
  }
  if (phone.length < 7 || phone.length > 20) {
    return res.status(400).json({ success: false, message: 'رقم الهاتف غير صحيح' });
  }
  if (description.length < 10) {
    return res.status(400).json({ success: false, message: 'وصف الطلب يجب أن يكون 10 أحرف على الأقل' });
  }

  const attachment = req.file ? req.file.filename : null;
  const request_number = generateRequestNumber();

  try {
    const [result] = await pool.query(
      `INSERT INTO requests (request_number, full_name, phone, email, service_type, description, attachment)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [request_number, full_name.trim(), phone.trim(), email?.trim() || null, service_type, description.trim(), attachment]
    );

    const [rows] = await pool.query('SELECT * FROM requests WHERE id = ?', [result.insertId]);
    const newRequest = rows[0];

    // Emit socket event
    const io = req.app.get('io');
    if (io) {
      io.to('admin-room').emit('new-request', {
        id: newRequest.id,
        request_number: newRequest.request_number,
        full_name: newRequest.full_name,
        service_type: newRequest.service_type,
        created_at: newRequest.created_at,
      });
    }

    // Send email notification (async, don't wait)
    sendNewRequestNotification(newRequest).catch(console.error);

    res.status(201).json({
      success: true,
      message: 'تم إرسال طلبك بنجاح! سنتواصل معك قريباً.',
      request_number,
    });
  } catch (error) {
    console.error('Create request error:', error);
    res.status(500).json({ success: false, message: 'حدث خطأ أثناء إرسال الطلب' });
  }
};

// ADMIN: Get all requests with filters
const getRequests = async (req, res) => {
  const { status, search, page = 1, limit = 20, sort = 'created_at', order = 'DESC' } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let whereClause = '1=1';
  const params = [];

  if (status && ['new', 'processing', 'completed', 'cancelled'].includes(status)) {
    whereClause += ' AND status = ?';
    params.push(status);
  }

  if (search && search.trim()) {
    whereClause += ' AND (full_name LIKE ? OR phone LIKE ? OR request_number LIKE ? OR service_type LIKE ?)';
    const s = `%${search.trim()}%`;
    params.push(s, s, s, s);
  }

  const validSorts = ['created_at', 'updated_at', 'full_name', 'status', 'service_type'];
  const sortCol = validSorts.includes(sort) ? sort : 'created_at';
  const sortOrder = order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

  try {
    const [rows] = await pool.query(
      `SELECT * FROM requests WHERE ${whereClause} ORDER BY ${sortCol} ${sortOrder} LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) as total FROM requests WHERE ${whereClause}`,
      params
    );

    res.json({
      success: true,
      requests: rows,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (error) {
    console.error('Get requests error:', error);
    res.status(500).json({ success: false, message: 'خطأ في جلب الطلبات' });
  }
};

// ADMIN: Get single request
const getRequest = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM requests WHERE id = ?', [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    }
    res.json({ success: true, request: rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, message: 'خطأ في جلب الطلب' });
  }
};

// ADMIN: Update request status
const updateRequestStatus = async (req, res) => {
  const { status, notes } = req.body;
  const validStatuses = ['new', 'processing', 'completed', 'cancelled'];

  if (!status || !validStatuses.includes(status)) {
    return res.status(400).json({ success: false, message: 'الحالة المحددة غير صحيحة' });
  }

  try {
    const [existing] = await pool.query('SELECT * FROM requests WHERE id = ?', [req.params.id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    }

    await pool.query(
      'UPDATE requests SET status = ?, notes = ? WHERE id = ?',
      [status, notes || null, req.params.id]
    );

    const [updated] = await pool.query('SELECT * FROM requests WHERE id = ?', [req.params.id]);
    const request = updated[0];

    // Emit socket event for status update
    const io = req.app.get('io');
    if (io) {
      io.to('admin-room').emit('request-updated', {
        id: request.id,
        status: request.status,
        updated_at: request.updated_at,
      });
    }

    // Notify client via email
    if (request.email) {
      sendStatusUpdateEmail(request).catch(console.error);
    }

    res.json({ success: true, message: 'تم تحديث حالة الطلب', request });
  } catch (error) {
    console.error('Update request error:', error);
    res.status(500).json({ success: false, message: 'خطأ في تحديث الطلب' });
  }
};

// ADMIN: Delete request
const deleteRequest = async (req, res) => {
  try {
    const [existing] = await pool.query('SELECT id, attachment FROM requests WHERE id = ?', [req.params.id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    }

    // Delete attachment file if exists
    if (existing[0].attachment) {
      const fs = require('fs');
      const path = require('path');
      const filePath = path.join(__dirname, '../../uploads', existing[0].attachment);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }

    await pool.query('DELETE FROM requests WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'تم حذف الطلب بنجاح' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'خطأ في حذف الطلب' });
  }
};

// ADMIN: Get statistics
const getStats = async (req, res) => {
  try {
    const [[stats]] = await pool.query(`
      SELECT
        COUNT(*) AS total,
        SUM(status = 'new') AS new_count,
        SUM(status = 'processing') AS processing_count,
        SUM(status = 'completed') AS completed_count,
        SUM(status = 'cancelled') AS cancelled_count,
        SUM(DATE(created_at) = CURDATE()) AS today_count
      FROM requests
    `);
    res.json({ success: true, stats });
  } catch (error) {
    res.status(500).json({ success: false, message: 'خطأ في جلب الإحصائيات' });
  }
};

module.exports = { createRequest, getRequests, getRequest, updateRequestStatus, deleteRequest, getStats };
