const express = require('express');
const router = express.Router();
const { login, getProfile, changePassword } = require('../controllers/authController');
const { authMiddleware } = require('../middleware/auth');

// POST /api/auth/login
router.post('/login', login);

// GET /api/auth/profile (protected)
router.get('/profile', authMiddleware, getProfile);

// PUT /api/auth/change-password (protected)
router.put('/change-password', authMiddleware, changePassword);

module.exports = router;
