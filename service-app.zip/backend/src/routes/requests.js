const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const {
  createRequest,
  getRequests,
  getRequest,
  updateRequestStatus,
  deleteRequest,
  getStats,
} = require('../controllers/requestController');

// PUBLIC: Submit new request
router.post('/', upload.single('attachment'), createRequest);

// ADMIN protected routes
router.get('/', authMiddleware, getRequests);
router.get('/stats', authMiddleware, getStats);
router.get('/:id', authMiddleware, getRequest);
router.patch('/:id/status', authMiddleware, updateRequestStatus);
router.delete('/:id', authMiddleware, deleteRequest);

module.exports = router;
