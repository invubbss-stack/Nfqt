const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.EMAIL_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const sendNewRequestNotification = async (request) => {
  if (!process.env.EMAIL_USER || !process.env.ADMIN_NOTIFY_EMAIL) return;

  const statusMap = {
    new: 'جديد',
    processing: 'قيد المعالجة',
    completed: 'مكتمل',
    cancelled: 'ملغي'
  };

  const html = `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; direction: rtl; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #1a1a2e, #16213e); color: white; padding: 30px; text-align: center; }
        .header h1 { margin: 0; font-size: 24px; }
        .badge { display: inline-block; background: #e63946; color: white; padding: 4px 12px; border-radius: 20px; font-size: 13px; margin-top: 8px; }
        .body { padding: 30px; }
        .field { margin-bottom: 16px; border-bottom: 1px solid #f0f0f0; padding-bottom: 16px; }
        .field:last-child { border-bottom: none; }
        .label { font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px; }
        .value { font-size: 16px; color: #1a1a2e; font-weight: 500; }
        .footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #888; }
        .btn { display: inline-block; background: #1a1a2e; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-size: 14px; margin-top: 16px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🔔 طلب خدمة جديد</h1>
          <span class="badge">رقم الطلب: ${request.request_number}</span>
        </div>
        <div class="body">
          <div class="field">
            <div class="label">الاسم الكامل</div>
            <div class="value">${request.full_name}</div>
          </div>
          <div class="field">
            <div class="label">رقم الهاتف</div>
            <div class="value">${request.phone}</div>
          </div>
          ${request.email ? `<div class="field"><div class="label">البريد الإلكتروني</div><div class="value">${request.email}</div></div>` : ''}
          <div class="field">
            <div class="label">نوع الخدمة</div>
            <div class="value">${request.service_type}</div>
          </div>
          <div class="field">
            <div class="label">وصف الطلب</div>
            <div class="value">${request.description}</div>
          </div>
          <div class="field">
            <div class="label">تاريخ الإنشاء</div>
            <div class="value">${new Date(request.created_at).toLocaleString('ar-SA')}</div>
          </div>
          <div style="text-align:center; margin-top: 20px;">
            <a href="${process.env.FRONTEND_URL || 'http://localhost:3000'}/admin/requests/${request.id}" class="btn">
              عرض الطلب في لوحة التحكم
            </a>
          </div>
        </div>
        <div class="footer">
          تم إرسال هذا الإشعار تلقائياً من نظام إدارة الطلبات
        </div>
      </div>
    </body>
    </html>
  `;

  try {
    await transporter.sendMail({
      from: `"نظام الطلبات" <${process.env.EMAIL_FROM || process.env.EMAIL_USER}>`,
      to: process.env.ADMIN_NOTIFY_EMAIL,
      subject: `🔔 طلب جديد #${request.request_number} - ${request.service_type}`,
      html,
    });
    console.log('📧 Email notification sent');
  } catch (error) {
    console.error('❌ Email notification failed:', error.message);
  }
};

const sendStatusUpdateEmail = async (request) => {
  if (!request.email || !process.env.EMAIL_USER) return;

  const statusMap = {
    new: { label: 'جديد', color: '#3b82f6', icon: '🆕' },
    processing: { label: 'قيد المعالجة', color: '#f59e0b', icon: '⚙️' },
    completed: { label: 'مكتمل', color: '#22c55e', icon: '✅' },
    cancelled: { label: 'ملغي', color: '#ef4444', icon: '❌' }
  };

  const s = statusMap[request.status] || statusMap.new;

  const html = `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head><meta charset="UTF-8">
    <style>
      body { font-family: Arial, sans-serif; background: #f5f5f5; direction: rtl; }
      .container { max-width: 600px; margin: 20px auto; background: white; border-radius: 12px; overflow: hidden; }
      .header { background: ${s.color}; color: white; padding: 24px; text-align: center; }
      .body { padding: 30px; }
      .status { display: inline-block; background: ${s.color}20; color: ${s.color}; border: 2px solid ${s.color}; padding: 6px 16px; border-radius: 20px; font-weight: bold; }
    </style>
    </head>
    <body>
      <div class="container">
        <div class="header"><h2>${s.icon} تحديث حالة طلبك</h2></div>
        <div class="body">
          <p>عزيزي/عزيزتي <strong>${request.full_name}</strong>،</p>
          <p>تم تحديث حالة طلبك رقم <strong>${request.request_number}</strong>:</p>
          <p><span class="status">${s.label}</span></p>
          ${request.notes ? `<p><strong>ملاحظات:</strong> ${request.notes}</p>` : ''}
          <p>شكراً لثقتك بنا.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  try {
    await transporter.sendMail({
      from: `"نظام الطلبات" <${process.env.EMAIL_FROM || process.env.EMAIL_USER}>`,
      to: request.email,
      subject: `تحديث طلبك #${request.request_number} - ${s.label}`,
      html,
    });
  } catch (error) {
    console.error('❌ Status email failed:', error.message);
  }
};

module.exports = { sendNewRequestNotification, sendStatusUpdateEmail };
