import { useEffect, useRef, useState, useCallback } from 'react';
import { io } from 'socket.io-client';

const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000';

export const useSocket = (onNewRequest, onRequestUpdated) => {
  const socketRef = useRef(null);
  const [connected, setConnected] = useState(false);

  const connect = useCallback(() => {
    const token = localStorage.getItem('admin_token');
    if (!token) return;

    socketRef.current = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 2000,
      reconnectionAttempts: 10,
    });

    socketRef.current.on('connect', () => {
      setConnected(true);
      socketRef.current.emit('join-admin', token);
    });

    socketRef.current.on('disconnect', () => setConnected(false));

    socketRef.current.on('new-request', (data) => {
      if (onNewRequest) onNewRequest(data);
    });

    socketRef.current.on('request-updated', (data) => {
      if (onRequestUpdated) onRequestUpdated(data);
    });

    socketRef.current.on('connect_error', (err) => {
      console.warn('Socket connection error:', err.message);
    });
  }, [onNewRequest, onRequestUpdated]);

  const disconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
      setConnected(false);
    }
  }, []);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  return { connected, disconnect, reconnect: connect };
};
