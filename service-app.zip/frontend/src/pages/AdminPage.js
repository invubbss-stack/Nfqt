import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../hooks/useSocket';
import api from '../utils/api';

const STATUS_LABELS = {
  new: { label: 'جديد', badge: 'badge-new', icon: '🆕' },
  processing: { label: 'قيد المعالجة', badge: 'badge-processing', icon: '⚙️' },
  completed: { label: 'مكتمل', badge: 'badge-completed', icon: '✅' },
  cancelled: { label: 'ملغي', badge: 'badge-cancelled', icon: '❌' },
};

export default function AdminPage() {
  const { admin, logout } = useAuth();
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState({ status: '', search: '', page: 1 });
  const [pagination, setPagination] = useState({});
  const [notifications, setNotifications] = useState([]);
  const [updating, setUpdating] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const notifRef = useRef([]);

  const addNotification = useCallback((msg) => {
    const id = Date.now();
    setNotifications(p => [...p, { id, ...msg }]);
    setTimeout(() => setNotifications(p => p.filter(n => n.id !== id)), 5000);
  }, []);

  const handleNewRequest = useCallback((data) => {
    addNotification({ type: 'new', text: `طلب جديد: ${data.full_name} - ${data.service_type}`, number: data.request_number });
    fetchRequests();
    fetchStats();
  }, []);

  const handleRequestUpdated = useCallback(() => {
    fetchRequests();
  }, []);

  const { connected } = useSocket(handleNewRequest, handleRequestUpdated);

  const fetchRequests = useCallback(async () => {
    try {
      const params = {};
      if (filter.status) params.status = filter.status;
      if (filter.search) params.search = filter.search;
      params.page = filter.page;
      params.limit = 15;
      const { data } = await api.get('/requests', { params });
      setRequests(data.requests);
      setPagination(data.pagination);
    } catch { /* handled by interceptor */ }
    finally { setLoading(false); }
  }, [filter]);

  const fetchStats = async () => {
    try {
      const { data } = await api.get('/requests/stats');
      setStats(data.stats);
    } catch {}
  };

  useEffect(() => { fetchRequests(); }, [fetchRequests]);
  useEffect(() => { fetchStats(); }, []);

  const updateStatus = async (id, status, notes) => {
    setUpdating(true);
    try {
      const { data } = await api.patch(`/requests/${id}/status`, { status, notes });
      setSelected(data.request);
      addNotification({ type: 'success', text: 'تم تحديث الحالة بنجاح' });
      fetchRequests();
      fetchStats();
    } catch (err) {
      addNotification({ type: 'error', text: 'فشل تحديث الحالة' });
    } finally { setUpdating(false); }
  };

  const deleteRequest = async (id) => {
    try {
      await api.delete(`/requests/${id}`);
      setDeleteConfirm(null);
      if (selected?.id === id) setSelected(null);
      addNotification({ type: 'success', text: 'تم حذف الطلب' });
      fetchRequests();
      fetchStats();
    } catch { addNotification({ type: 'error', text: 'فشل حذف الطلب' }); }
  };

  const formatDate = (d) => new Date(d).toLocaleString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <span style={{fontSize:28}}>🔧</span>
          <div><div style={{fontWeight:800, fontSize:16}}>خدماتي</div><div style={{fontSize:11, opacity:0.6}}>لوحة التحكم</div></div>
        </div>
        <nav className="sidebar-nav">
          <div className="nav-item active">📋 الطلبات</div>
        </nav>
        {stats && (
          <div className="sidebar-stats">
            <div className="ss-item"><span>إجمالي</span><strong>{stats.total}</strong></div>
            <div className="ss-item new"><span>جديدة</span><strong>{stats.new_count}</strong></div>
            <div className="ss-item proc"><span>معالجة</span><strong>{stats.processing_count}</strong></div>
            <div className="ss-item done"><span>مكتملة</span><strong>{stats.completed_count}</strong></div>
          </div>
        )}
        <div className="sidebar-footer">
          <div style={{fontSize:13, opacity:0.7, marginBottom:8}}>👑 {admin?.name}</div>
          <div className={`conn-status ${connected ? 'on' : 'off'}`}>
            <span className="dot" />{connected ? 'متصل' : 'غير متصل'}
          </div>
          <button className="btn btn-outline btn-sm btn-full" style={{marginTop:12, color:'white', borderColor:'rgba(255,255,255,0.2)'}} onClick={() => { logout(); navigate('/admin/login'); }}>
            تسجيل خروج
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="admin-main">
        {/* Stats cards */}
        {stats && (
          <div className="stats-row animate-fade-in">
            {[
              { label: 'إجمالي الطلبات', value: stats.total, icon: '📊', color: '#3b82f6' },
              { label: 'طلبات اليوم', value: stats.today_count, icon: '📅', color: '#8b5cf6' },
              { label: 'جديدة', value: stats.new_count, icon: '🆕', color: '#f59e0b' },
              { label: 'مكتملة', value: stats.completed_count, icon: '✅', color: '#22c55e' },
            ].map(s => (
              <div key={s.label} className="stat-card">
                <div className="stat-card-icon" style={{background:`${s.color}15`, color:s.color}}>{s.icon}</div>
                <div>
                  <div className="stat-card-value" style={{color:s.color}}>{s.value}</div>
                  <div className="stat-card-label">{s.label}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Filters */}
        <div className="filters-bar animate-fade-in">
          <input
            className="form-input" placeholder="🔍 بحث بالاسم، الهاتف، رقم الطلب..."
            value={filter.search}
            onChange={e => setFilter(p => ({ ...p, search: e.target.value, page: 1 }))}
            style={{maxWidth:320}}
          />
          <div className="status-filters">
            {[['', 'الكل'], ['new', '🆕 جديد'], ['processing', '⚙️ معالجة'], ['completed', '✅ مكتمل'], ['cancelled', '❌ ملغي']].map(([val, lbl]) => (
              <button key={val} className={`filter-btn ${filter.status === val ? 'active' : ''}`}
                onClick={() => setFilter(p => ({ ...p, status: val, page: 1 }))}>
                {lbl}
              </button>
            ))}
          </div>
        </div>

        {/* Table + Detail split */}
        <div className={`content-area ${selected ? 'with-detail' : ''}`}>
          <div className="table-panel card animate-fade-in">
            {loading ? (
              <div className="loading-state">
                {[1,2,3,4,5].map(i => <div key={i} className="skeleton" style={{height:52, marginBottom:8, borderRadius:8}} />)}
              </div>
            ) : requests.length === 0 ? (
              <div className="empty-state">
                <div style={{fontSize:48}}>📭</div>
                <h3>لا توجد طلبات</h3>
                <p>لم يتم العثور على طلبات مطابقة للفلتر الحالي</p>
              </div>
            ) : (
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>رقم الطلب</th>
                      <th>الاسم</th>
                      <th>الهاتف</th>
                      <th>الخدمة</th>
                      <th>الحالة</th>
                      <th>التاريخ</th>
                      <th>إجراء</th>
                    </tr>
                  </thead>
                  <tbody>
                    {requests.map(r => (
                      <tr key={r.id} className={selected?.id === r.id ? 'row-selected' : ''} style={{cursor:'pointer'}} onClick={() => setSelected(r)}>
                        <td><code style={{fontSize:12, background:'var(--bg)', padding:'2px 6px', borderRadius:4}}>{r.request_number}</code></td>
                        <td><strong>{r.full_name}</strong></td>
                        <td style={{direction:'ltr', textAlign:'right'}}>{r.phone}</td>
                        <td><span style={{fontSize:13}}>{r.service_type}</span></td>
                        <td>
                          <span className={`badge ${STATUS_LABELS[r.status]?.badge}`}>
                            {STATUS_LABELS[r.status]?.icon} {STATUS_LABELS[r.status]?.label}
                          </span>
                        </td>
                        <td style={{fontSize:12, color:'var(--text-muted)', whiteSpace:'nowrap'}}>{formatDate(r.created_at)}</td>
                        <td>
                          <button className="btn btn-danger btn-sm" onClick={e => { e.stopPropagation(); setDeleteConfirm(r.id); }}>🗑</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {/* Pagination */}
                {pagination.totalPages > 1 && (
                  <div className="pagination">
                    <button className="btn btn-outline btn-sm" disabled={filter.page === 1}
                      onClick={() => setFilter(p => ({ ...p, page: p.page - 1 }))}>
                      السابق
                    </button>
                    <span style={{fontSize:13, color:'var(--text-secondary)'}}>
                      صفحة {pagination.page} من {pagination.totalPages} ({pagination.total} طلب)
                    </span>
                    <button className="btn btn-outline btn-sm" disabled={filter.page >= pagination.totalPages}
                      onClick={() => setFilter(p => ({ ...p, page: p.page + 1 }))}>
                      التالي
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Request Detail Panel */}
          {selected && <RequestDetail request={selected} onUpdate={updateStatus} onClose={() => setSelected(null)} updating={updating} formatDate={formatDate} />}
        </div>
      </main>

      {/* Notifications */}
      <div className="notifications-container">
        {notifications.map(n => (
          <div key={n.id} className={`notify-toast notify-${n.type}`}>
            <div style={{fontWeight:700, marginBottom:n.number ? 4 : 0}}>
              {n.type === 'new' ? '🔔 طلب جديد!' : n.type === 'success' ? '✅' : '❌'} {n.text}
            </div>
            {n.number && <div style={{fontSize:12, opacity:0.8}}>{n.number}</div>}
          </div>
        ))}
      </div>

      {/* Delete confirmation modal */}
      {deleteConfirm && (
        <div className="modal-overlay" onClick={() => setDeleteConfirm(null)}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <div style={{fontSize:40, marginBottom:12}}>🗑️</div>
            <h3>تأكيد الحذف</h3>
            <p>هل أنت متأكد من حذف هذا الطلب؟ لا يمكن التراجع.</p>
            <div style={{display:'flex', gap:12, marginTop:24, justifyContent:'center'}}>
              <button className="btn btn-outline" onClick={() => setDeleteConfirm(null)}>إلغاء</button>
              <button className="btn btn-danger" style={{background:'var(--error)', color:'white'}} onClick={() => deleteRequest(deleteConfirm)}>حذف</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .admin-layout { display: flex; min-height: 100vh; }

        /* Sidebar */
        .sidebar { width: 240px; background: var(--primary); color: white; display: flex; flex-direction: column;
          padding: 24px 16px; gap: 0; flex-shrink: 0; }
        .sidebar-logo { display: flex; align-items: center; gap: 10px; padding: 0 8px 24px; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 20px; }
        .sidebar-nav { flex: 1; }
        .nav-item { padding: 10px 12px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer;
          display: flex; align-items: center; gap: 8px; transition: background 0.2s; color: rgba(255,255,255,0.7); }
        .nav-item.active, .nav-item:hover { background: rgba(255,255,255,0.1); color: white; }
        .sidebar-stats { background: rgba(255,255,255,0.05); border-radius: 10px; padding: 14px; margin: 16px 0; }
        .ss-item { display: flex; justify-content: space-between; padding: 5px 0; font-size: 13px; color: rgba(255,255,255,0.7); }
        .ss-item.new strong { color: #fbbf24; }
        .ss-item.proc strong { color: #60a5fa; }
        .ss-item.done strong { color: #4ade80; }
        .ss-item strong { font-size: 16px; }
        .sidebar-footer { border-top: 1px solid rgba(255,255,255,0.1); padding-top: 16px; }
        .conn-status { display: flex; align-items: center; gap: 6px; font-size: 12px; color: rgba(255,255,255,0.6); }
        .conn-status .dot { width: 8px; height: 8px; border-radius: 50%; }
        .conn-status.on .dot { background: #4ade80; box-shadow: 0 0 6px #4ade80; }
        .conn-status.off .dot { background: #ef4444; }

        /* Main */
        .admin-main { flex: 1; padding: 24px; overflow-x: hidden; background: var(--bg); min-width: 0; }

        /* Stats row */
        .stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 20px; }
        .stat-card { background: var(--surface); border-radius: var(--radius-lg); padding: 20px;
          display: flex; align-items: center; gap: 16px; border: 1px solid var(--border); box-shadow: var(--shadow-sm); }
        .stat-card-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; }
        .stat-card-value { font-size: 28px; font-weight: 800; line-height: 1; }
        .stat-card-label { font-size: 12px; color: var(--text-muted); margin-top: 4px; font-weight: 500; }

        /* Filters */
        .filters-bar { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
        .status-filters { display: flex; gap: 8px; flex-wrap: wrap; }
        .filter-btn { padding: 8px 14px; border-radius: 20px; border: 2px solid var(--border); background: var(--surface);
          font-family: inherit; font-size: 13px; font-weight: 600; cursor: pointer; color: var(--text-secondary); transition: all 0.2s; }
        .filter-btn:hover { border-color: var(--accent); color: var(--accent); }
        .filter-btn.active { background: var(--accent); border-color: var(--accent); color: white; }

        /* Content area */
        .content-area { display: flex; gap: 16px; align-items: flex-start; }
        .content-area.with-detail .table-panel { flex: 1; min-width: 0; }
        .table-panel { flex: 1; }
        .row-selected { background: #fff7ed !important; }

        /* Pagination */
        .pagination { display: flex; align-items: center; justify-content: center; gap: 16px; padding: 16px; border-top: 1px solid var(--border); }

        /* Empty / Loading */
        .empty-state { text-align: center; padding: 60px 20px; color: var(--text-secondary); }
        .empty-state h3 { font-size: 18px; margin: 12px 0 8px; color: var(--text-primary); }
        .loading-state { padding: 20px; }

        /* Notifications */
        .notifications-container { position: fixed; top: 20px; left: 20px; z-index: 9999; display: flex; flex-direction: column; gap: 10px; }
        .notify-new { background: var(--primary); border-right-color: var(--accent); }
        .notify-success { background: #14532d; border-right-color: var(--success); }
        .notify-error { background: #7f1d1d; border-right-color: var(--error); }

        /* Modal */
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 10000; }
        .modal-box { background: var(--surface); border-radius: var(--radius-xl); padding: 40px; text-align: center; max-width: 360px; width: 90%; box-shadow: var(--shadow-lg); }
        .modal-box h3 { font-size: 20px; font-weight: 700; margin-bottom: 8px; }
        .modal-box p { color: var(--text-secondary); font-size: 14px; }

        @media (max-width: 1024px) {
          .stats-row { grid-template-columns: repeat(2, 1fr); }
          .content-area.with-detail { flex-direction: column; }
        }
        @media (max-width: 768px) {
          .sidebar { display: none; }
          .admin-main { padding: 16px; }
          .stats-row { grid-template-columns: repeat(2, 1fr); gap: 12px; }
        }
      `}</style>
    </div>
  );
}

function RequestDetail({ request, onUpdate, onClose, updating, formatDate }) {
  const [status, setStatus] = useState(request.status);
  const [notes, setNotes] = useState(request.notes || '');
  const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

  useEffect(() => {
    setStatus(request.status);
    setNotes(request.notes || '');
  }, [request]);

  return (
    <div className="detail-panel card animate-slide-in">
      <div className="detail-header">
        <div>
          <div style={{fontSize:11, color:'var(--text-muted)', fontWeight:700, letterSpacing:1}}>تفاصيل الطلب</div>
          <div style={{fontWeight:800, fontSize:15}}>{request.request_number}</div>
        </div>
        <button onClick={onClose} style={{background:'none', border:'none', cursor:'pointer', fontSize:20, color:'var(--text-muted)', lineHeight:1}}>✕</button>
      </div>
      <div className="detail-body">
        {[
          { label: 'الاسم الكامل', value: request.full_name, icon: '👤' },
          { label: 'رقم الهاتف', value: request.phone, icon: '📱', ltr: true },
          { label: 'البريد الإلكتروني', value: request.email || '—', icon: '📧' },
          { label: 'نوع الخدمة', value: request.service_type, icon: '🔧' },
          { label: 'تاريخ الإنشاء', value: formatDate(request.created_at), icon: '📅' },
        ].map(f => (
          <div key={f.label} className="detail-field">
            <div className="detail-label">{f.icon} {f.label}</div>
            <div className="detail-value" style={f.ltr ? {direction:'ltr', textAlign:'right'} : {}}>{f.value}</div>
          </div>
        ))}

        <div className="detail-field">
          <div className="detail-label">📝 وصف الطلب</div>
          <div className="detail-desc">{request.description}</div>
        </div>

        {request.attachment && (
          <div className="detail-field">
            <div className="detail-label">📎 المرفق</div>
            <a href={`${API_URL.replace('/api','')}/uploads/${request.attachment}`} target="_blank" rel="noreferrer" className="attachment-link">
              عرض / تحميل المرفق
            </a>
          </div>
        )}

        <div className="detail-field">
          <div className="detail-label">🏷️ تغيير الحالة</div>
          <div className="status-buttons">
            {Object.entries({ new:'جديد', processing:'معالجة', completed:'مكتمل', cancelled:'ملغي' }).map(([val, lbl]) => (
              <button key={val} className={`status-btn ${status === val ? 'active-'+val : ''}`}
                onClick={() => setStatus(val)}>
                {lbl}
              </button>
            ))}
          </div>
        </div>

        <div className="detail-field">
          <div className="detail-label">📋 ملاحظات</div>
          <textarea className="form-textarea" value={notes} onChange={e => setNotes(e.target.value)}
            placeholder="أضف ملاحظات على الطلب..." rows={3} style={{fontSize:14}} />
        </div>

        <button className="btn btn-primary btn-full" onClick={() => onUpdate(request.id, status, notes)} disabled={updating}>
          {updating ? <><span className="spinner" /> جاري الحفظ...</> : '💾 حفظ التغييرات'}
        </button>
      </div>

      <style>{`
        .detail-panel { width: 340px; flex-shrink: 0; position: sticky; top: 0; max-height: calc(100vh - 48px); overflow-y: auto; }
        .detail-header { padding: 16px 20px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
        .detail-body { padding: 16px 20px; display: flex; flex-direction: column; gap: 12px; }
        .detail-field { }
        .detail-label { font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
        .detail-value { font-size: 14px; font-weight: 600; color: var(--text-primary); }
        .detail-desc { font-size: 13px; color: var(--text-secondary); background: var(--bg); padding: 10px 12px; border-radius: 8px; line-height: 1.7; }
        .attachment-link { display: inline-block; background: var(--accent-light); color: var(--accent); padding: 6px 14px; border-radius: 6px; font-size: 13px; font-weight: 600; text-decoration: none; }
        .attachment-link:hover { background: var(--accent); color: white; }
        .status-buttons { display: flex; gap: 6px; flex-wrap: wrap; }
        .status-btn { padding: 6px 14px; border-radius: 6px; border: 2px solid var(--border); background: var(--surface);
          font-family: inherit; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; color: var(--text-secondary); }
        .status-btn:hover { border-color: var(--accent); }
        .status-btn.active-new { background: #eff6ff; border-color: #2563eb; color: #2563eb; }
        .status-btn.active-processing { background: #fffbeb; border-color: #d97706; color: #d97706; }
        .status-btn.active-completed { background: #f0fdf4; border-color: #16a34a; color: #16a34a; }
        .status-btn.active-cancelled { background: #fef2f2; border-color: #dc2626; color: #dc2626; }
      `}</style>
    </div>
  );
}
