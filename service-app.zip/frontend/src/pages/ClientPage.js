import React, { useState } from 'react';
import api from '../utils/api';

const SERVICE_TYPES = [
  'صيانة وإصلاح',
  'تركيب وتجهيز',
  'استشارة فنية',
  'تصميم وإنشاء',
  'نظافة ومكافحة حشرات',
  'أعمال كهربائية',
  'أعمال سباكة',
  'دهانات وديكور',
  'تكييف وتبريد',
  'خدمة أخرى',
];

const initialForm = {
  full_name: '',
  phone: '',
  email: '',
  service_type: '',
  description: '',
  attachment: null,
};

export default function ClientPage() {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(null);
  const [filePreview, setFilePreview] = useState(null);

  const validate = () => {
    const errs = {};
    if (!form.full_name.trim() || form.full_name.length < 3) errs.full_name = 'الاسم يجب أن يكون 3 أحرف على الأقل';
    if (!form.phone.trim()) errs.phone = 'رقم الهاتف مطلوب';
    else if (!/^[\d\s\+\-\(\)]{7,20}$/.test(form.phone)) errs.phone = 'رقم الهاتف غير صحيح';
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = 'البريد الإلكتروني غير صحيح';
    if (!form.service_type) errs.service_type = 'اختر نوع الخدمة';
    if (!form.description.trim() || form.description.length < 10) errs.description = 'وصف الطلب يجب أن يكون 10 أحرف على الأقل';
    return errs;
  };

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'attachment' && files[0]) {
      const file = files[0];
      setForm(p => ({ ...p, attachment: file }));
      if (file.type.startsWith('image/')) {
        setFilePreview(URL.createObjectURL(file));
      } else {
        setFilePreview(null);
      }
    } else {
      setForm(p => ({ ...p, [name]: value }));
    }
    if (errors[name]) setErrors(p => ({ ...p, [name]: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) return setErrors(errs);

    setLoading(true);
    const formData = new FormData();
    Object.entries(form).forEach(([k, v]) => { if (v) formData.append(k, v); });

    try {
      const { data } = await api.post('/requests', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setSubmitted(data.request_number);
    } catch (err) {
      setErrors({ global: err.response?.data?.message || 'حدث خطأ، يرجى المحاولة مرة أخرى' });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setForm(initialForm);
    setErrors({});
    setSubmitted(null);
    setFilePreview(null);
  };

  if (submitted) {
    return (
      <div className="client-page">
        <Header />
        <main className="client-main">
          <div className="success-card animate-fade-in">
            <div className="success-icon">✅</div>
            <h2>تم استقبال طلبك بنجاح!</h2>
            <p>رقم طلبك هو:</p>
            <div className="request-number">{submitted}</div>
            <p className="success-note">احتفظ بهذا الرقم للمتابعة. سيتواصل معك فريقنا في أقرب وقت.</p>
            <button className="btn btn-primary btn-lg" onClick={resetForm}>
              إرسال طلب آخر
            </button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="client-page">
      <Header />
      <main className="client-main">
        <div className="hero animate-fade-in">
          <div className="hero-content">
            <span className="hero-badge">خدماتنا في خدمتك</span>
            <h1>أرسل طلبك الآن</h1>
            <p>نصلك في أقرب وقت ممكن مع ضمان جودة الخدمة</p>
          </div>
          <div className="hero-stats">
            <div className="stat"><span className="stat-num">+500</span><span>عميل</span></div>
            <div className="stat"><span className="stat-num">98%</span><span>رضا</span></div>
            <div className="stat"><span className="stat-num">24/7</span><span>دعم</span></div>
          </div>
        </div>

        <div className="form-card animate-fade-in">
          <div className="form-card-header">
            <h2>نموذج طلب الخدمة</h2>
            <p>يرجى ملء جميع الحقول المطلوبة</p>
          </div>

          {errors.global && (
            <div className="alert alert-error">{errors.global}</div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className="form-grid">
              <div className="form-group">
                <label className="form-label">الاسم الكامل <span className="required">*</span></label>
                <input
                  className={`form-input ${errors.full_name ? 'error' : ''}`}
                  name="full_name" value={form.full_name}
                  onChange={handleChange} placeholder="أدخل اسمك الكامل"
                />
                {errors.full_name && <span className="form-error">⚠ {errors.full_name}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">رقم الهاتف <span className="required">*</span></label>
                <input
                  className={`form-input ${errors.phone ? 'error' : ''}`}
                  name="phone" value={form.phone} type="tel"
                  onChange={handleChange} placeholder="05XXXXXXXX"
                />
                {errors.phone && <span className="form-error">⚠ {errors.phone}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">البريد الإلكتروني <span style={{color:'var(--text-muted)', fontWeight:400}}>(اختياري)</span></label>
                <input
                  className={`form-input ${errors.email ? 'error' : ''}`}
                  name="email" value={form.email} type="email"
                  onChange={handleChange} placeholder="example@email.com"
                />
                {errors.email && <span className="form-error">⚠ {errors.email}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">نوع الخدمة <span className="required">*</span></label>
                <select
                  className={`form-select ${errors.service_type ? 'error' : ''}`}
                  name="service_type" value={form.service_type}
                  onChange={handleChange}
                >
                  <option value="">-- اختر نوع الخدمة --</option>
                  {SERVICE_TYPES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                {errors.service_type && <span className="form-error">⚠ {errors.service_type}</span>}
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">وصف الطلب <span className="required">*</span></label>
              <textarea
                className={`form-textarea ${errors.description ? 'error' : ''}`}
                name="description" value={form.description}
                onChange={handleChange}
                placeholder="اشرح طلبك بالتفصيل: ما المشكلة؟ ما الموقع؟ متى تحتاج الخدمة؟"
                rows={5}
              />
              <div className="char-count">{form.description.length} حرف</div>
              {errors.description && <span className="form-error">⚠ {errors.description}</span>}
            </div>

            <div className="form-group">
              <label className="form-label">مرفق أو صورة <span style={{color:'var(--text-muted)', fontWeight:400}}>(اختياري - صور، PDF، Word)</span></label>
              <div className="file-upload-area" onClick={() => document.getElementById('attachment-input').click()}>
                {filePreview ? (
                  <img src={filePreview} alt="معاينة" className="file-preview-img" />
                ) : (
                  <>
                    <div className="upload-icon">📎</div>
                    <p>انقر لرفع ملف أو اسحبه هنا</p>
                    <span>الحد الأقصى: 5MB</span>
                  </>
                )}
                {form.attachment && !filePreview && (
                  <p className="file-name">📄 {form.attachment.name}</p>
                )}
              </div>
              <input
                id="attachment-input"
                type="file"
                name="attachment"
                onChange={handleChange}
                accept="image/*,.pdf,.doc,.docx,.txt"
                style={{ display: 'none' }}
              />
            </div>

            <div className="form-footer">
              <p className="form-disclaimer">
                🔒 بياناتك محمية ولن تُشارك مع أي طرف آخر
              </p>
              <button type="submit" className="btn btn-primary btn-lg btn-full" disabled={loading}>
                {loading ? <><span className="spinner" /> جاري الإرسال...</> : '🚀 إرسال الطلب'}
              </button>
            </div>
          </form>
        </div>

        <div className="features-section animate-fade-in">
          {[
            { icon: '⚡', title: 'سرعة الاستجابة', desc: 'نتواصل معك خلال ساعات' },
            { icon: '🛡️', title: 'ضمان الجودة', desc: 'خدمة معتمدة ومضمونة' },
            { icon: '💰', title: 'أسعار تنافسية', desc: 'أفضل الأسعار في السوق' },
            { icon: '🔧', title: 'فريق متخصص', desc: 'خبراء معتمدون في مجالاتهم' },
          ].map(f => (
            <div key={f.title} className="feature-card">
              <div className="feature-icon">{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          ))}
        </div>
      </main>
      <Footer />

      <style>{`
        .client-page { min-height: 100vh; display: flex; flex-direction: column; }
        .client-main { flex: 1; max-width: 860px; margin: 0 auto; padding: 40px 20px; width: 100%; }

        /* Hero */
        .hero { background: linear-gradient(135deg, var(--primary) 0%, #1e3a5f 100%);
          color: white; padding: 48px 40px; border-radius: var(--radius-xl); margin-bottom: 32px; position: relative; overflow: hidden; }
        .hero::before { content: ''; position: absolute; top: -50%; right: -20%; width: 400px; height: 400px;
          background: radial-gradient(circle, rgba(249,115,22,0.15) 0%, transparent 70%); pointer-events: none; }
        .hero-badge { background: rgba(249,115,22,0.2); border: 1px solid rgba(249,115,22,0.4);
          color: #fb923c; padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: 700; }
        .hero-content h1 { font-size: clamp(28px, 5vw, 42px); font-weight: 800; margin: 12px 0 8px; line-height: 1.3; }
        .hero-content p { font-size: 16px; opacity: 0.85; }
        .hero-stats { display: flex; gap: 32px; margin-top: 32px; flex-wrap: wrap; }
        .stat { display: flex; flex-direction: column; align-items: center; }
        .stat-num { font-size: 28px; font-weight: 800; color: var(--accent); }
        .stat span:last-child { font-size: 13px; opacity: 0.8; }

        /* Form card */
        .form-card { background: var(--surface); border-radius: var(--radius-xl); border: 1px solid var(--border);
          box-shadow: 0 8px 32px rgba(0,0,0,0.06); overflow: hidden; margin-bottom: 40px; }
        .form-card-header { padding: 28px 32px 0; margin-bottom: 24px; }
        .form-card-header h2 { font-size: 22px; font-weight: 700; color: var(--text-primary); }
        .form-card-header p { font-size: 14px; color: var(--text-secondary); margin-top: 4px; }
        form { padding: 0 32px 32px; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0 20px; }
        .char-count { font-size: 12px; color: var(--text-muted); text-align: left; margin-top: 4px; }

        /* File upload */
        .file-upload-area { border: 2px dashed var(--border); border-radius: var(--radius-md); padding: 32px;
          text-align: center; cursor: pointer; transition: all 0.2s; color: var(--text-secondary); }
        .file-upload-area:hover { border-color: var(--accent); background: var(--accent-light); }
        .upload-icon { font-size: 32px; margin-bottom: 8px; }
        .file-upload-area p { font-size: 14px; margin: 4px 0; }
        .file-upload-area span { font-size: 12px; color: var(--text-muted); }
        .file-preview-img { max-height: 150px; border-radius: 8px; object-fit: contain; }
        .file-name { font-weight: 600; color: var(--primary); }

        /* Form footer */
        .form-footer { margin-top: 24px; }
        .form-disclaimer { font-size: 13px; color: var(--text-muted); margin-bottom: 16px; }

        /* Alert */
        .alert { padding: 14px 20px; border-radius: var(--radius-sm); margin: 0 32px 20px; font-size: 14px; font-weight: 500; }
        .alert-error { background: #fef2f2; color: var(--error); border: 1px solid #fecaca; }

        /* Success */
        .success-card { background: var(--surface); border-radius: var(--radius-xl); padding: 60px 40px;
          text-align: center; box-shadow: 0 8px 32px rgba(0,0,0,0.06); border: 1px solid var(--border); }
        .success-icon { font-size: 64px; margin-bottom: 20px; }
        .success-card h2 { font-size: 28px; font-weight: 800; color: var(--primary); margin-bottom: 12px; }
        .request-number { background: var(--primary); color: white; font-size: 24px; font-weight: 800;
          padding: 16px 32px; border-radius: var(--radius-md); margin: 16px auto; display: inline-block;
          letter-spacing: 2px; }
        .success-note { color: var(--text-secondary); margin: 16px 0 32px; }

        /* Features */
        .features-section { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
        .feature-card { background: var(--surface); border-radius: var(--radius-lg); padding: 24px 20px;
          text-align: center; border: 1px solid var(--border); transition: transform 0.2s, box-shadow 0.2s; }
        .feature-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); }
        .feature-icon { font-size: 36px; margin-bottom: 12px; }
        .feature-card h3 { font-size: 15px; font-weight: 700; margin-bottom: 6px; }
        .feature-card p { font-size: 13px; color: var(--text-secondary); }

        @media (max-width: 768px) {
          .form-grid { grid-template-columns: 1fr; }
          .features-section { grid-template-columns: 1fr 1fr; }
          .form-card-header, form { padding-right: 20px; padding-left: 20px; }
          .hero { padding: 32px 24px; }
          .hero-stats { gap: 20px; }
        }
        @media (max-width: 480px) {
          .features-section { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
}

function Header() {
  return (
    <header style={{background:'var(--primary)', color:'white', padding:'0 24px'}}>
      <div style={{maxWidth:860, margin:'0 auto', display:'flex', alignItems:'center', justifyContent:'space-between', height:64}}>
        <div style={{display:'flex', alignItems:'center', gap:10}}>
          <span style={{fontSize:28}}>🔧</span>
          <div>
            <div style={{fontWeight:800, fontSize:18, lineHeight:1.2}}>خدماتي</div>
            <div style={{fontSize:11, opacity:0.7}}>منصة طلب الخدمات</div>
          </div>
        </div>
        <a href="/admin/login" style={{color:'rgba(255,255,255,0.7)', fontSize:13, textDecoration:'none'}}>
          لوحة التحكم ←
        </a>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer style={{background:'var(--primary)', color:'rgba(255,255,255,0.6)', padding:'20px 24px', textAlign:'center', fontSize:13, marginTop:'auto'}}>
      © {new Date().getFullYear()} خدماتي — جميع الحقوق محفوظة
    </footer>
  );
}
