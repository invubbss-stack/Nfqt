import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const { login, loading } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [showPass, setShowPass] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.email || !form.password) return setError('جميع الحقول مطلوبة');
    const result = await login(form.email, form.password);
    if (result.success) navigate('/admin');
    else setError(result.message);
  };

  return (
    <div className="login-page">
      <div className="login-bg" />
      <div className="login-card animate-fade-in">
        <div className="login-header">
          <div className="login-logo">🔧</div>
          <h1>لوحة التحكم</h1>
          <p>سجّل دخولك للمتابعة</p>
        </div>

        {error && (
          <div className="login-error">
            ⚠ {error}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label">البريد الإلكتروني</label>
            <input
              className="form-input"
              type="email"
              value={form.email}
              onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
              placeholder="admin@example.com"
              autoComplete="email"
            />
          </div>
          <div className="form-group">
            <label className="form-label">كلمة المرور</label>
            <div style={{ position: 'relative' }}>
              <input
                className="form-input"
                type={showPass ? 'text' : 'password'}
                value={form.password}
                onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                placeholder="••••••••"
                autoComplete="current-password"
                style={{ paddingLeft: 44 }}
              />
              <button type="button" onClick={() => setShowPass(p => !p)}
                style={{position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', fontSize:18, color:'var(--text-muted)'}}>
                {showPass ? '🙈' : '👁️'}
              </button>
            </div>
          </div>
          <button type="submit" className="btn btn-primary btn-lg btn-full" disabled={loading} style={{marginTop:8}}>
            {loading ? <><span className="spinner" /> جاري التحقق...</> : '🔐 تسجيل الدخول'}
          </button>
        </form>

        <a href="/" style={{display:'block', textAlign:'center', marginTop:20, color:'var(--text-muted)', fontSize:13, textDecoration:'none'}}>
          ← العودة للموقع
        </a>
      </div>

      <style>{`
        .login-page { min-height: 100vh; display: flex; align-items: center; justify-content: center;
          background: var(--primary); position: relative; padding: 20px; }
        .login-bg { position: absolute; inset: 0; background: radial-gradient(ellipse at 30% 50%, rgba(249,115,22,0.12) 0%, transparent 60%),
          radial-gradient(ellipse at 80% 20%, rgba(59,130,246,0.08) 0%, transparent 50%); pointer-events: none; }
        .login-card { background: var(--surface); border-radius: var(--radius-xl); padding: 40px;
          width: 100%; max-width: 420px; box-shadow: 0 24px 64px rgba(0,0,0,0.3); position: relative; z-index: 1; }
        .login-header { text-align: center; margin-bottom: 32px; }
        .login-logo { font-size: 48px; margin-bottom: 12px; }
        .login-header h1 { font-size: 26px; font-weight: 800; color: var(--primary); }
        .login-header p { color: var(--text-secondary); font-size: 14px; margin-top: 6px; }
        .login-error { background: #fef2f2; color: var(--error); border: 1px solid #fecaca;
          border-radius: var(--radius-sm); padding: 12px 16px; margin-bottom: 20px; font-size: 14px; font-weight: 500; }
      `}</style>
    </div>
  );
}
